import ModalHeader from "./ModalHeader";
import ModalHeader2 from "./ModalHeader2";
import ModalLayout from "./ModalLayout";

export { ModalHeader, ModalHeader2, ModalLayout };
