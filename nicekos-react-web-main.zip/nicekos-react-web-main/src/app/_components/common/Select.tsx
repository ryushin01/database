import React from "react";

export default function Select() {
  return (
    <ul>
      <li className="p-3 text-base text-[#7D7D7D] font-medium">기본순</li>
      <li className="p-3 text-base text-[#7D7D7D] font-medium">기본순</li>
      <li className="p-3 text-base text-[#7D7D7D] font-medium">기본순</li>
      <li className="p-3 text-base text-[#7D7D7D] font-medium">기본순</li>
      <li className="p-3 text-base text-[#7D7D7D] font-medium">기본순</li>
    </ul>
  );
}
