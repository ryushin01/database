export const DOCUMENTS_LIST = [
  {
    id: 1,
    category: "일반 매매",
    name: "매도인 개인 혹은 법인 인감증명서",
  },
  {
    id: 2,
    category: "분양",
    name: "분양계약서 혹은 공급계약서",
  },
  {
    id: 3,
    category: "경매",
    name: "매각허가결정문/등기부등본",
  },
  {
    id: 4,
    category: "신탁등기",
    name: "위임장(신탁등기변경)",
  },
  {
    id: 5,
    category: "임차권 명령 및 가압류 말소",
    name: "가압류집행 해제신청서",
  },
];
